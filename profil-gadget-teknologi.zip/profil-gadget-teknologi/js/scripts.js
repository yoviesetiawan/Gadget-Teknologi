// js/scripts.js

document.addEventListener('DOMContentLoaded', function() {
    // --- Toggle Menu untuk Mobile ---
    const menuToggle = document.querySelector('.menu-toggle');
    const navUl = document.querySelector('nav ul');
    const searchForm = document.querySelector('.search-form'); // TAMBAHKAN INI

    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navUl.classList.toggle('active');
            searchForm.classList.toggle('active'); // DAN INI
            
            // Ubah ikon hamburger menjadi 'X' saat menu aktif
            const icon = this.querySelector('i');
            if (icon.classList.contains('fa-bars')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }

    // --- Smooth Scrolling untuk link anchor (jika ada) ---
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if(target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // --- Simple Form Validation Feedback (Contoh) ---
    // Kamu bisa mengembangkan ini menjadi lebih kompleks
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Ini hanya contoh, validasi utama tetap di backend (PHP)
            // const requiredFields = form.querySelectorAll('[required]');
            // let isValid = true;
            // requiredFields.forEach(field => {
            //     if (!field.value) {
            //         isValid = false;
            //         field.style.borderColor = 'red'; // Beri indikator error
            //     } else {
            //         field.style.borderColor = ''; // Hapus indikator
            //     }
            // });
            // if (!isValid) {
            //     e.preventDefault();
            //     alert('Harap isi semua field yang wajib diisi.');
            // }
        });
    });

    // --- Header shadow saat scroll ---
    const header = document.querySelector('header');
    const onScroll = () => {
        if (!header) return;
        if (window.scrollY > 4) header.classList.add('scrolled');
        else header.classList.remove('scrolled');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    // --- Reveal on scroll ---
    const revealEls = document.querySelectorAll('.reveal');
    if (revealEls.length) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });
        revealEls.forEach(el => io.observe(el));
    }

    // --- Button ripple effect ---
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', function (e) {
            const rect = this.getBoundingClientRect();
            const ripple = document.createElement('span');
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            ripple.className = 'ripple';
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        }, { passive: true });
    });
});
