<?php
// gallery.php
 $pageTitle = 'Galeri';
require_once 'includes/header.php';
require_once 'functions.php';

// Proses upload gambar (sederhana)
 $message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['gambar'])) {
    $target_dir = "images/uploads/";
    $target_file = $target_dir . basename($_FILES["gambar"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $check = getimagesize($_FILES["gambar"]["tmp_name"]);
    if($check !== false) {
        $uploadOk = 1;
    } else {
        $message = "File yang diupload bukan gambar.";
        $uploadOk = 0;
    }

    if ($_FILES["gambar"]["size"] > 5000000) {
        $message = "Maaf, ukuran file terlalu besar.";
        $uploadOk = 0;
    }

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        $message = "Maaf, hanya file JPG, JPEG, PNG & GIF yang diperbolehkan.";
        $uploadOk = 0;
    }

    if ($uploadOk == 0) {
        $message = "Maaf, file anda tidak terupload. " . $message;
    } else {
        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
            global $pdo;
            $stmt = $pdo->prepare("INSERT INTO gallery_images (nama_file, keterangan) VALUES (?, ?)");
            $stmt->execute([basename($_FILES["gambar"]["name"]), $_POST['keterangan']]);
            $message = "File ". htmlspecialchars( basename( $_FILES["gambar"]["name"])). " berhasil diupload.";
            header("Location: gallery.php?status=success");
            exit();
        } else {
            $message = "Maaf, terjadi error saat mengupload file.";
        }
    }
}

if(isset($_GET['status']) && $_GET['status'] == 'success') {
    $message = "Gambar berhasil diupload ke galeri!";
}

 $galleryImages = getAllGalleryImages();
?>

<div class="container">
    <h2>Galeri Gadget</h2>
    
    <?php if ($message): ?>
        <p style="background-color: var(--light-pink); padding: 10px; border-radius: 10px; color: var(--dark-purple);"><?php echo $message; ?></p>
    <?php endif; ?>

    <h3>Upload Gambar Baru</h3>
    <form action="gallery.php" method="post" enctype="multipart/form-data" style="margin-bottom: 40px;">
        <div class="form-group">
            <label for="gambar">Pilih Gambar:</label>
            <input type="file" name="gambar" id="gambar" required>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan (Opsional):</label>
            <input type="text" name="keterangan" id="keterangan">
        </div>
        <button type="submit" class="btn">Upload Gambar</button>
    </form>

    <h3>Koleksi Kami</h3>
    <!-- PERUBAHAN DIMULAI DI SINI -->
    <!-- Kita bungkus grid di dalam div dengan class 'gallery-lightbox' -->
    <div class="gallery-lightbox">
        <div class="grid">
            <?php if (count($galleryImages) > 0): ?>
                <?php foreach ($galleryImages as $img): ?>
                    <!-- PERUBAHAN: Gambar dibungkus dengan tag <a> -->
                    <a href="images/uploads/<?php echo htmlspecialchars($img['nama_file']); ?>" class="gallery-item" title="<?php echo htmlspecialchars($img['keterangan']); ?>">
                        <img src="images/uploads/<?php echo htmlspecialchars($img['nama_file']); ?>" alt="<?php echo htmlspecialchars($img['keterangan']); ?>" class="card-image">
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada gambar di galeri.</p>
            <?php endif; ?>
        </div>
    </div>
    <!-- PERUBAHAN SELESAI DI SINI -->
</div>

<?php require_once 'includes/footer.php'; ?>