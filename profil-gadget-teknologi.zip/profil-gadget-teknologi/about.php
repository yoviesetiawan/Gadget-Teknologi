<?php
// about.php
 $pageTitle = 'Tentang Kami';
require_once 'includes/header.php';
?>

<!-- Hero Section Khusus Halaman About -->
<section class="about-hero">
    <div class="container">
        <h1>Tentang GadgetCute 💖</h1>
        <p>Kami adalah tim pecinta gadget yang percaya bahwa teknologi itu harusnya <strong>fun, fresh, dan fashionable!</strong></p>
    </div>
</section>

<div class="container">
    
    <!-- Section: Kenapa GadgetCute? -->
    <section class="about-section">
        <h2>Kenapa GadgetCute?</h2>
        <p>
            Halo! 👋 Selamat datang di <strong>GadgetCute</strong>, tempatnya profil gadget teknologi dengan sentuhan yang manis dan menyenangkan!
        </p>
        <p>
            Kami sadar, dunia teknologi seringkali terlihat kaku, serius, dan didominasi warna netral. Di sinilah kami hadir! GadgetCute lahir dari keinginan untuk membawa warna, desain yang <em>clean, fresh, dan tentu saja, lucu!</em> ke dalam ulasan gadget. Dengan palet warna ungu, pink, dan putih, kami berharap bisa membuat pengalaman menjelajah dunia teknologi kamu jadi lebih berwarna dan nggak membosankan.
        </p>
    </section>

    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">

    <!-- Section: Tim di Balik Layar -->
    <section class="about-section">
        <h2>Tim di Balik Layar</h2>
        <p>Kenalan sama tim yang selalu bersemangat kasih kamu info gadget terkini!</p>
        
        <div class="team-grid">
            <div class="team-card">
                <img src="images/team/ceo.jpg" alt="CEO GadgetCute">
                <h3>Citra Anggraini</h3>
                <p>Chief Executive Officer</p>
                <p>Pendongkrak semangat tim dengan segala ide warna-warni.</p>
                <div class="team-social">
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <div class="team-card">
                <img src="images/team/tech-lead.jpg" alt="Tech Lead">
                <h3>Budi Santoso</h3>
                <p>Tech Lead & Reviewer</p>
                <p>Juru uji coba semua gadget, dari yang paling murah sampai yang paling mahal.</p>
                <div class="team-social">
                    <a href="#"><i class="fab fa-github"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <div class="team-card">
                <img src="images/team/content-writer.jpg" alt="Content Writer">
                <h3>Siti Nurhaliza</h3>
                <p>Content Writer</p>
                <p>Penyihir kata yang mengubah spesifikasi rumit jadi cerita yang seru.</p>
                <div class="team-social">
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>
    </section>

    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">

    <!-- Section: Nilai-Nilai Kami -->
    <section class="about-section">
        <h2>Nilai-Nilai Kami</h2>
        <div class="values-grid">
            <div class="value-item">
                <div class="value-icon">
                    <i class="fas fa-sparkles"></i>
                </div>
                <h3>Desain Lucu & Menarik</h3>
                <p>Kami percaya estetika itu penting. Website dan konten kami dirancang untuk menyenangkan mata.</p>
            </div>
            <div class="value-item">
                <div class="value-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Info Terpercaya</h3>
                <p>Setiap ulasan dan tips kami berdasarkan riset dan pengujian yang mendalam. No hoax!</p>
            </div>
            <div class="value-item">
                <div class="value-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <h3>Buat Kamu</h3>
                <p>Semua yang kami lakukan adalah untuk memberikan pengalaman terbaik dan informasi yang berguna untuk kamu.</p>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section">
        <h2>Ada Pertanyaan atau Mau Kerja Sama?</h2>
        <p>Kami selalu senang mendengar dari kamu! Jangan ragu untuk menyapa.</p>
        <a href="contact.php" class="btn">Hubungi Kami</a>
    </section>

</div>

<?php require_once 'includes/footer.php'; ?>