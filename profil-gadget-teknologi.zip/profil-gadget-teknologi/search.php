<?php
// search.php
require_once 'includes/header.php';
require_once 'functions.php';

 $query = isset($_GET['q']) ? trim($_GET['q']) : '';
 $pageTitle = 'Hasil Pencarian untuk: ' . htmlspecialchars($query);

 $results = [];
if (!empty($query)) {
    $results = searchItems($query);
}
?>

<div class="container">
    <h1>Hasil Pencarian</h1>
    <p>Menampilkan hasil untuk kata kunci: <strong>"<?php echo htmlspecialchars($query); ?>"</strong></p>

    <?php if (empty($query)): ?>
        <p>Silakan masukkan kata kunci di kotak pencarian.</p>
    <?php elseif (empty($results)): ?>
        <p>Yah, tidak ada hasil yang ditemukan untuk "<strong><?php echo htmlspecialchars($query); ?></strong>". Coba kata kunci lain, ya!</p>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($results as $item): ?>
                <div class="card">
                    <?php if ($item['type'] === 'gadget'): ?>
                        <img src="images/gadgets/<?php echo htmlspecialchars($item['gambar']); ?>" alt="<?php echo htmlspecialchars($item['nama']); ?>" class="card-image">
                        <a href="profile-detail.php?id=<?php echo $item['id']; ?>" class="btn" style="margin-top: 15px;">Lihat Detail</a>
                    <?php else: // news ?>
                        <img src="images/news/<?php echo htmlspecialchars($item['gambar']); ?>" alt="<?php echo htmlspecialchars($item['nama']); ?>" class="card-image">
                        <a href="news-detail.php?id=<?php echo $item['id']; ?>" class="btn" style="margin-top: 15px;">Baca Selengkapnya</a>
                    <?php endif; ?>
                    <div class="card-content">
                        <h3><?php echo htmlspecialchars($item['nama']); ?></h3>
                        <p><?php echo substr(htmlspecialchars($item['deskripsi']), 0, 100) . '...'; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>