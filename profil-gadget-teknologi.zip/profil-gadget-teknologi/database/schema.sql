-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 29, 2025 at 05:56 AM
-- Server version: 8.0.40
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gadget_teknologi`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subjek` varchar(255) DEFAULT NULL,
  `pesan` text NOT NULL,
  `tanggal_kirim` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gadgets`
--

CREATE TABLE `gadgets` (
  `id` int NOT NULL,
  `nama` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `spesifikasi` text,
  `harga` decimal(10,2) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `tanggal_ditambahkan` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `kategori` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `gadgets`
--

INSERT INTO `gadgets` (`id`, `nama`, `deskripsi`, `spesifikasi`, `harga`, `gambar`, `tanggal_ditambahkan`, `kategori`) VALUES
(1, 'SparklePhone X', 'Smartphone dengan desain berkilau dan performa tangguh untuk gaya hidup modern.', 'Layar: 6.5\" AMOLED, Chipset: GlimmerChip G8, RAM: 8GB, Kamera: 108MP', 8999000.00, 'sparklephone-x.jpg', '2025-10-29 03:36:35', 'Smartphone'),
(2, 'CuteTab Pro', 'Tablet lucu dengan warna pastel yang memanjakan mata, sempurna untuk hobi dan produktivitas.', 'Layar: 10.9\" Liquid Retina, Chipset: FluffyChip A14, Storage: 128GB, Stylus: BubblePen', 7499000.00, 'cutetab-pro.jpg', '2025-10-29 03:36:35', 'Tablet'),
(3, 'GemPods Mini', 'Earphone nirkabel mungil dengan suara jernih dan kualitas bass yang menggelegar.', 'Driver: 12mm, Battery Life: 24h (dengan case), Noise Cancellation: Active, Charging: USB-C', 1299000.00, 'gempods-mini.jpg', '2025-10-29 03:36:35', 'Audio');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_images`
--

CREATE TABLE `gallery_images` (
  `id` int NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `tanggal_upload` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `gallery_images`
--

INSERT INTO `gallery_images` (`id`, `nama_file`, `keterangan`, `tanggal_upload`) VALUES
(1, 'sample-gadget-1.jpg', 'Tampilan depan SparklePhone X', '2025-10-29 03:36:35'),
(2, 'sample-gadget-2.jpg', 'CuteTab Pro dalam warna lavender', '2025-10-29 03:36:35'),
(3, 'sample-gadget-3.jpg', 'GemPods Mini di dalam charging case', '2025-10-29 03:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int NOT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `penulis` varchar(100) DEFAULT NULL,
  `tanggal_publikasi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `judul`, `konten`, `gambar`, `penulis`, `tanggal_publikasi`) VALUES
(1, '5 Tips Merawat Gadget Kesayanganmu', '1. Gunakan casing dan screen protector. 2. Hindari charging semalaman. 3. Jauhkan dari air. 4. Bersihkan secara rutin. 5. Update software!', 'tips-merawat.jpg', 'Admin Gadget', '2023-10-26'),
(2, 'Tren Teknologi Gadget di Tahun 2024', 'Dari AI yang lebih pintar hingga desain yang berkelanjutan, tahun 2024 diprediksi akan menjadi tahunnya inovasi gadget yang memukau.', 'tren-2024.jpg', 'Tim Editor', '2023-10-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gadgets`
--
ALTER TABLE `gadgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_images`
--
ALTER TABLE `gallery_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gadgets`
--
ALTER TABLE `gadgets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gallery_images`
--
ALTER TABLE `gallery_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
