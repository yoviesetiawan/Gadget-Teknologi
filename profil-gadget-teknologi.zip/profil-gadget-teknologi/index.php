<?php
// index.php
 $pageTitle = 'Beranda';
require_once 'includes/header.php';
require_once 'functions.php';

// Ambil data untuk ditampilkan di beranda
 $latestGadgets = array_slice(getAllGadgets(), 0, 3);
 $latestNews = array_slice(getAllNews(), 0, 2); // Ambil 2 berita terbaru
 $latestGalleryImages = array_slice(getAllGalleryImages(), 0, 4); // Ambil 4 gambar terbaru
?>

<!-- Hero Section (Sudah ada) -->
<section class="hero">
    <div class="container">
        <h1>Selamat Datang di GadgetCute! 💖</h1>
        <p>Temukan profil gadget teknologi paling lucu dan kekinian di sini.</p>
    </div>
</section>

<div class="container">
    <!-- Section Gadget Terbaru (Sudah ada) -->
    <section id="latest-gadgets">
        <h2>Gadget Terbaru</h2>
        <div class="grid">
            <?php if (count($latestGadgets) > 0): ?>
                <?php foreach ($latestGadgets as $gadget): ?>
                    <div class="card">
                        <img src="images/gadgets/<?php echo htmlspecialchars($gadget['gambar']); ?>" alt="<?php echo htmlspecialchars($gadget['nama']); ?>" class="card-image">
                        <div class="card-content">
                            <h3><?php echo htmlspecialchars($gadget['nama']); ?></h3>
                            <p><?php echo substr(htmlspecialchars($gadget['deskripsi']), 0, 100) . '...'; ?></p>
                            <a href="profile-detail.php?id=<?php echo $gadget['id']; ?>" class="btn" style="margin-top: 15px;">Lihat Detail</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada gadget yang ditambahkan.</p>
            <?php endif; ?>
        </div>
        <div style="text-align: center; margin-top: 30px;">
            <a href="profiles.php" class="btn btn-secondary">Lihat Semua Gadget</a>
        </div>
    </section>

    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">

    <!-- SECTION BARU: Berita & Tips Terkini -->
    <section id="latest-news">
        <h2>Berita & Tips Terkini</h2>
        <div class="grid">
            <?php if (count($latestNews) > 0): ?>
                <?php foreach ($latestNews as $article): ?>
                    <div class="card">
                        <img src="images/news/<?php echo htmlspecialchars($article['gambar']); ?>" alt="<?php echo htmlspecialchars($article['judul']); ?>" class="card-image">
                        <div class="card-content">
                            <h3><?php echo htmlspecialchars($article['judul']); ?></h3>
                            <p><small>Oleh <?php echo htmlspecialchars($article['penulis']); ?> pada <?php echo date('d M Y', strtotime($article['tanggal_publikasi'])); ?></small></p>
                            <p><?php echo substr(htmlspecialchars($article['konten']), 0, 100) . '...'; ?></p>
                            <a href="news-detail.php?id=<?php echo $article['id']; ?>" class="btn" style="margin-top: 15px;">Baca Selengkapnya</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada berita.</p>
            <?php endif; ?>
        </div>
        <div style="text-align: center; margin-top: 30px;">
            <a href="news.php" class="btn btn-secondary">Baca Semua Berita</a>
        </div>
    </section>

    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">

    <!-- SECTION BARU: Sneak Peek Galeri -->
    <section id="gallery-preview">
        <h2>Sneak Peek Galeri</h2>
        <div class="grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
            <?php if (count($latestGalleryImages) > 0): ?>
                <?php foreach ($latestGalleryImages as $img): ?>
                    <div class="card">
                        <img src="images/uploads/<?php echo htmlspecialchars($img['nama_file']); ?>" alt="<?php echo htmlspecialchars($img['keterangan']); ?>" class="card-image" style="height: 150px;">
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Galeri masih kosong.</p>
            <?php endif; ?>
        </div>
        <div style="text-align: center; margin-top: 30px;">
            <a href="gallery.php" class="btn btn-secondary">Lihat Semua Galeri</a>
        </div>
    </section>

</div>

<?php require_once 'includes/footer.php'; ?>