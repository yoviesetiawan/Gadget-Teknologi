<?php
// functions.php

require_once 'config.php';

// Fungsi untuk mengambil semua data gadget (sudah di-enhance)
function getAllGadgets($category = null, $sortBy = 'tanggal_ditambahkan', $sortOrder = 'DESC') {
    global $pdo;

    $sql = "SELECT * FROM gadgets WHERE 1=1";
    $params = [];

    if ($category && $category !== 'all') {
        $sql .= " AND kategori = :category";
        $params[':category'] = $category;
    }

    $allowedSortColumns = ['nama', 'harga', 'tanggal_ditambahkan'];
    if (in_array($sortBy, $allowedSortColumns)) {
        $sql .= " ORDER BY " . $sortBy;
    } else {
        $sql .= " ORDER BY tanggal_ditambahkan";
    }

    $sortOrder = strtoupper($sortOrder);
    if ($sortOrder === 'ASC' || $sortOrder === 'DESC') {
        $sql .= " " . $sortOrder;
    } else {
        $sql .= " DESC";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fungsi untuk mengambil satu data gadget berdasarkan ID
function getGadgetById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM gadgets WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fungsi untuk mengambil semua berita
function getAllNews() {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM news ORDER BY tanggal_publikasi DESC");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fungsi untuk mengambil satu berita berdasarkan ID
function getNewsById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fungsi untuk mengambil semua gambar dari galeri
function getAllGalleryImages() {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM gallery_images ORDER BY tanggal_upload DESC");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// --- FUNGSI BARU UNTUK ITEM TERKAIT (SUDAH DIPERBAIKI) ---

// Fungsi untuk mengambil gadget terkait (acak)
function getRelatedGadgets($currentId, $limit = 3) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM gadgets WHERE id != ? ORDER BY RAND() LIMIT ?");
    
    // Bind parameter secara eksplisit untuk menghindari error
    $stmt->bindValue(1, $currentId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fungsi untuk mengambil berita terkait (acak)
function getRelatedNews($currentId, $limit = 3) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM news WHERE id != ? ORDER BY RAND() LIMIT ?");
    
    // Bind parameter secara eksplisit untuk menghindari error
    $stmt->bindValue(1, $currentId, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function searchItems($query) {
    global $pdo;

    // Sanitasi input untuk keamanan
    $searchTerm = '%' . htmlspecialchars($query) . '%';

    // Cari di tabel gadgets
    $stmtGadgets = $pdo->prepare("SELECT id, nama, deskripsi, gambar, 'gadget' as type FROM gadgets WHERE nama LIKE ? OR deskripsi LIKE ?");
    $stmtGadgets->execute([$searchTerm, $searchTerm]);
    $gadgets = $stmtGadgets->fetchAll(PDO::FETCH_ASSOC);

    // Cari di tabel news
    $stmtNews = $pdo->prepare("SELECT id, judul as nama, konten as deskripsi, gambar, 'news' as type FROM news WHERE judul LIKE ? OR konten LIKE ?");
    $stmtNews->execute([$searchTerm, $searchTerm]);
    $news = $stmtNews->fetchAll(PDO::FETCH_ASSOC);

    // Gabungkan hasilnya
    return array_merge($gadgets, $news);
}
?>