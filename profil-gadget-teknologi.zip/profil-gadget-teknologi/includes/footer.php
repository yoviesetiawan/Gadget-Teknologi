<?php
// includes/footer.php
?>
    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Profil Gadget Teknologi. Dibuat dengan <i class="fas fa-heart" style="color: var(--soft-pink);"></i> untuk kamu.</p>
            <div class="social-links">
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-facebook"></i></a>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/scripts.js"></script>

    <!-- TAMBAHKAN JS LIGHTBOX DI SINI -->
    <!-- 1. Load library SimpleLightbox -->
    <script src="https://cdn.jsdelivr.net/npm/simplelightbox@2.14.2/dist/simple-lightbox.min.js"></script>
    
    <!-- 2. Inisialisasi SimpleLightbox -->
    <script>
        // Tunggu hingga seluruh halaman dimuat
        document.addEventListener('DOMContentLoaded', function() {
            // Inisialisasi SimpleLightbox untuk semua link (<a>) 
            // yang berada di dalam elemen dengan class 'gallery-lightbox'
            new SimpleLightbox('.gallery-lightbox a', { 
                captions: true,        // Tampilkan keterangan gambar
                captionDelay: 200,     // Tunda tampilan keterangan 200ms
                captionPosition: 'bottom', // Letakkan keterangan di bawah
            });
        });
    </script>
</body>
</html>