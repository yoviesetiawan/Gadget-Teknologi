<?php
// includes/header.php
// Memeriksa apakah variabel $pageTitle sudah didefinisikan, jika tidak, gunakan default
 $pageTitle = isset($pageTitle) ? $pageTitle : 'Profil Gadget Teknologi';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    <!-- Google Fonts: Poppins (Lucu & Modern) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome untuk Ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <!-- CSS Utama -->
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsive.css">

    <!-- TAMBAHKAN CSS LIGHTBOX DI SINI -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/simplelightbox@2.14.2/dist/simple-lightbox.min.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php" class="logo">
                <!-- PERUBAHAN DI SINI: Gambar diganti dengan ikon -->
                <i class="fas fa-gem"></i>
                <span>GadgetCute</span>
            </a>
            <nav>
                <ul>
                    <li><a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>"><i class="fas fa-home"></i> Beranda</a></li>
                    <li><a href="profiles.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profiles.php' ? 'active' : ''; ?>"><i class="fas fa-microchip"></i> Gadget</a></li>
                    <li><a href="news.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'news.php' ? 'active' : ''; ?>"><i class="fas fa-newspaper"></i> Berita</a></li>
                    <li><a href="gallery.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'gallery.php' ? 'active' : ''; ?>"><i class="fas fa-images"></i> Galeri</a></li>
                    <li><a href="about.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active' : ''; ?>"><i class="fas fa-info-circle"></i> Tentang</a></li>
                    <li><a href="contact.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'active' : ''; ?>"><i class="fas fa-envelope"></i> Kontak</a></li>
                </ul>
                
                <!-- FORM PENCARIAN DITAMBAHKAN DI SINI -->
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Cari gadget atau berita..." required>
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>

                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>
    <main>