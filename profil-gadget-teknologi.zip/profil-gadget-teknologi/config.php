<?php
// config.php

// --- Pengaturan Koneksi Database untuk LOKAL (MAMP) ---
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'db_gadget_teknologi');

// Membuat koneksi menggunakan PDO dengan PORT KUSTOM
try {
    // !!! PERHATIKAN BAGIAN INI !!!
    // Kita menambahkan ;port=8889 karena di MAMP, MySQL berjalan di port 8889
    $pdo = new PDO("mysql:host=" . DB_HOST . ";port=8889;dbname=" . DB_NAME, DB_USER, DB_PASS);
    
    // Set mode error PDO ke Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
    // Jika koneksi gagal, hentikan script dan tampilkan pesan error yang jelas
    die("ERROR: Tidak bisa terhubung ke database. Pastikan:
         1. Server Apache & MySQL di MAMP sudah menyala (warna hijau).
         2. Port MySQL di MAMP adalah 8889 (sesuai config.php).
         3. Database 'db_gadget_teknologi' sudah dibuat di phpMyAdmin.
         Detail Error: " . $e->getMessage());
}
?>