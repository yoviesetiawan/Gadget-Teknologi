<?php
// news-detail.php
require_once 'includes/header.php';
require_once 'functions.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<div class='container'><h1>Error</h1><p>ID Artikel tidak valid.</p></div>";
    require_once 'includes/footer.php';
    exit;
}

 $article = getNewsById($_GET['id']);

if (!$article) {
    echo "<div class='container'><h1>Error</h1><p>Artikel tidak ditemukan.</p></div>";
    require_once 'includes/footer.php';
    exit;
}

 $pageTitle = htmlspecialchars($article['judul']);

// AMBIL BERITA TERKAIT MENGGUNAKAN FUNGSI BARU
 $relatedNews = getRelatedNews($article['id']);
?>

<div class="container">
    <div class="detail-container">
        <div>
            <img src="images/news/<?php echo htmlspecialchars($article['gambar']); ?>" alt="<?php echo htmlspecialchars($article['judul']); ?>" class="detail-image">
        </div>
        <div class="detail-info">
            <h1><?php echo htmlspecialchars($article['judul']); ?></h1>
            <p><small>Oleh <?php echo htmlspecialchars($article['penulis']); ?> pada <?php echo date('d M Y', strtotime($article['tanggal_publikasi'])); ?></small></p>
            <div><?php echo nl2br(htmlspecialchars($article['konten'])); ?></div>
        </div>
    </div>

    <!-- SECTION BARU: Berita Terkait -->
    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">
    
    <section id="related-items">
        <h2>Berita Terkait</h2>
        <div class="grid">
            <?php if (count($relatedNews) > 0): ?>
                <?php foreach ($relatedNews as $related): ?>
                    <div class="card">
                        <img src="images/news/<?php echo htmlspecialchars($related['gambar']); ?>" alt="<?php echo htmlspecialchars($related['judul']); ?>" class="card-image">
                        <div class="card-content">
                            <h3><?php echo htmlspecialchars($related['judul']); ?></h3>
                            <p><small><?php echo date('d M Y', strtotime($related['tanggal_publikasi'])); ?></small></p>
                            <p><?php echo substr(htmlspecialchars($related['konten']), 0, 100) . '...'; ?></p>
                            <a href="news-detail.php?id=<?php echo $related['id']; ?>" class="btn" style="margin-top: 15px;">Baca Selengkapnya</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada berita lain untuk saat ini.</p>
            <?php endif; ?>
        </div>
    </section>

</div>

<?php require_once 'includes/footer.php'; ?>