<?php
// styleguide.php
$pageTitle = 'Style Guide';
require_once 'includes/header.php';
?>
<section class="hero">
  <div class="container">
    <h1>Style Guide GadgetCute</h1>
    <p class="subtitle">Palet warna, typography, komponen, dan utilitas UI</p>
  </div>
</section>

<div class="container section">
  <div class="section-header">
    <h2>Warna</h2>
    <p class="text-muted">Pink & ungu sebagai primary, putih sebagai dasar.</p>
  </div>

  <div class="grid reveal">
    <div class="card">
      <div class="card-content">
        <h3>Primary Purple</h3>
        <div style="height:64px;border-radius:10px;background:var(--primary-purple);"></div>
        <p class="text-muted" style="margin-top:12px;">#6a4c93</p>
      </div>
    </div>
    <div class="card">
      <div class="card-content">
        <h3>Soft Pink</h3>
        <div style="height:64px;border-radius:10px;background:var(--soft-pink);"></div>
        <p class="text-muted" style="margin-top:12px;">#ffacd5</p>
      </div>
    </div>
    <div class="card">
      <div class="card-content">
        <h3>Light Pink</h3>
        <div style="height:64px;border-radius:10px;background:var(--light-pink);"></div>
        <p class="text-muted" style="margin-top:12px;">#ffeef8</p>
      </div>
    </div>
    <div class="card">
      <div class="card-content">
        <h3>Gradient</h3>
        <div style="height:64px;border-radius:10px;background:var(--gradient-primary);"></div>
        <p class="text-muted" style="margin-top:12px;">pink-300 → purple-300</p>
      </div>
    </div>
  </div>

  <hr class="divider" />

  <div class="section-header">
    <h2>Typography</h2>
    <p class="text-muted">Hierarchy yang jelas untuk struktur konten.</p>
  </div>
  <div class="reveal">
    <h1 style="margin-bottom:8px;">Judul H1</h1>
    <p class="subtitle">Subjudul / lead text</p>
    <p class="text-muted" style="margin-top:12px;">Body text contoh dengan warna netral.</p>
  </div>

  <hr class="divider" />

  <div class="section-header">
    <h2>Buttons</h2>
    <p class="text-muted">Varian tombol untuk berbagai kebutuhan UI.</p>
  </div>
  <div class="reveal" style="display:flex;gap:16px;flex-wrap:wrap;">
    <button class="btn btn-lg btn-icon"><i class="fas fa-heart"></i> Primary</button>
    <button class="btn btn-secondary">Secondary</button>
    <button class="btn btn-outline">Outline</button>
    <button class="btn btn-ghost">Ghost</button>
    <button class="btn btn-sm" disabled>Disabled</button>
  </div>

  <hr class="divider" />

  <div class="section-header">
    <h2>Cards</h2>
    <p class="text-muted">Kartu konten dengan hover yang subtle.</p>
  </div>
  <div class="grid reveal">
    <div class="card">
      <img class="card-image" src="images/uploads/alfian(1) (1).png" alt="contoh" />
      <div class="card-content">
        <h3>Contoh Card</h3>
        <p class="text-muted">Deskripsi singkat untuk mendemokan gaya card yang clean dan modern.</p>
        <div class="cta-actions">
          <a href="#" class="btn btn-sm">Aksi</a>
          <a href="#" class="btn btn-outline btn-sm">Lainnya</a>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-content">
        <h3>Badge & Chip</h3>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <span class="badge">Baru</span>
          <span class="badge pink">Promo</span>
          <span class="chip"><i class="fas fa-microchip"></i> Gadget</span>
        </div>
      </div>
    </div>
  </div>

  <hr class="divider" />

  <div class="section-header">
    <h2>Forms</h2>
    <p class="text-muted">Input dengan fokus ring dan aksesibilitas lebih baik.</p>
  </div>
  <form class="reveal" action="#" method="post" style="max-width:600px;">
    <div class="form-group">
      <label>Nama</label>
      <input type="text" placeholder="Masukkan nama">
    </div>
    <div class="form-group">
      <label>Pesan</label>
      <textarea rows="4" placeholder="Tulis pesan"></textarea>
    </div>
    <div class="form-group">
      <label>Kategori</label>
      <select>
        <option>Gadget</option>
        <option>Berita</option>
      </select>
    </div>
    <button class="btn">Kirim</button>
  </form>
</div>

<?php require_once 'includes/footer.php'; ?>

