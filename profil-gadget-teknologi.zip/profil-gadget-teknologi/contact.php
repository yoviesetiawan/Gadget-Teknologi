<?php
// contact.php
 $pageTitle = 'Kontak Kami';
require_once 'includes/header.php';

// Inisialisasi variabel untuk pesan dan input
 $message = '';
 $success = false;
 $form_data = [
    'nama' => '',
    'email' => '',
    'subjek' => '',
    'pesan' => ''
];

// Proses pengiriman form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Simpan data yang diinput untuk ditampilkan kembali jika ada error
    $form_data = array_map('htmlspecialchars', $_POST);

    // Validasi sederhana di server (sebagai backup)
    if (!empty($_POST['nama']) && !empty($_POST['email']) && !empty($_POST['pesan'])) {
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            // Dalam aplikasi nyata, di sini kamu akan mengirim email atau menyimpan ke DB
            global $pdo;
            $stmt = $pdo->prepare("INSERT INTO contacts (nama, email, subjek, pesan) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_POST['nama'], $_POST['email'], $_POST['subjek'], $_POST['pesan']]);
            
            $success = true;
            $message = "Terima kasih! Pesan Anda telah berhasil dikirim. Kami akan segera menghubungi Anda.";
            // Kosongkan form setelah submit berhasil
            $form_data = ['nama' => '', 'email' => '', 'subjek' => '', 'pesan' => ''];
        } else {
            $message = "Harap masukkan alamat email yang valid.";
        }
    } else {
        $message = "Harap isi semua field yang wajib diisi.";
    }
}
?>

<div class="container">
    <section class="contact-page">
        <div class="contact-info">
            <h2>Hubungi Kami</h2>
            <p>Ada pertanyaan, saran, atau sekadar ingin say hai? Jangan ragu untuk menghubungi kami melalui formulir di samping. Kami sangat menantikan pesan dari kamu! 💖</p>
            
            <div class="info-item">
                <i class="fas fa-envelope"></i>
                <span>hello@gadgetcute.com</span>
            </div>
            <div class="info-item">
                <i class="fas fa-phone"></i>
                <span>+62 812-3456-7890</span>
            </div>
            <div class="info-item">
                <i class="fas fa-map-marker-alt"></i>
                <span>Jl. Kawaii No. 123, Jakarta, Indonesia</span>
            </div>
        </div>

        <div class="contact-form-wrapper">
            <?php if ($message): ?>
                <div class="form-message <?php echo $success ? 'success' : 'error'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form action="contact.php" method="POST" id="contactForm" novalidate>
                <div class="form-group">
                    <label for="nama">Nama Lengkap *</label>
                    <input type="text" name="nama" id="nama" value="<?php echo $form_data['nama']; ?>" required>
                    <small class="error-message"></small>
                </div>
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" name="email" id="email" value="<?php echo $form_data['email']; ?>" required>
                    <small class="error-message"></small>
                </div>
                <div class="form-group">
                    <label for="subjek">Subjek</label>
                    <select name="subjek" id="subjek">
                        <option value="">-- Pilih Subjek --</option>
                        <option value="Pertanyaan Umum" <?php echo ($form_data['subjek'] == 'Pertanyaan Umum') ? 'selected' : ''; ?>>Pertanyaan Umum</option>
                        <option value="Kerjasama" <?php echo ($form_data['subjek'] == 'Kerjasama') ? 'selected' : ''; ?>>Kerjasama</option>
                        <option value="Laporan Masalah" <?php echo ($form_data['subjek'] == 'Laporan Masalah') ? 'selected' : ''; ?>>Laporan Masalah</option>
                    </select>
                    <small class="error-message"></small>
                </div>
                <div class="form-group">
                    <label for="pesan">Pesan *</label>
                    <textarea name="pesan" id="pesan" rows="6" required><?php echo $form_data['pesan']; ?></textarea>
                    <small class="error-message"></small>
                </div>
                <button type="submit" class="btn">Kirim Pesan</button>
            </form>
        </div>
    </section>

    <!-- SECTION BARU: Peta Lokasi -->
    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">
    
    <section class="map-section">
        <h2>Temui Kami</h2>
        <div class="map-container">
            <!-- Ganti dengan embed peta kamu jika ada -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.521260322283!2d106.8195613507864!3d-6.194741395493371!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5390917b759%3A0x6b45e67356080477!2sMonas!5e0!3m2!1sen!2sid!4v1678886400000!5m2!1sen!2sid" 
                width="100%" 
                height="450" 
                style="border:0; border-radius: var(--border-radius);" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </section>

</div>

<?php require_once 'includes/footer.php'; ?>