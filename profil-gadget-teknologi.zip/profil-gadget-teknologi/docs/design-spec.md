# GadgetCute Design Spec

## Tujuan
Menciptakan UI/UX profesional, modern, clean, dan fresh dengan palet pink, ungu, dan putih yang harmonis dan konsisten.

## Palet & Sistem Warna
- Primary: `--primary-purple`, `--soft-pink`
- Secondary: `--purple-300`, `--pink-300`
- Background: `--white`, `--neutral-100`
- Accent: `--dark-purple`, `--pink-700`
- Gradients: `--gradient-soft` untuk hero, `--gradient-primary` untuk aksen
- Kontras teks: `--text-color` untuk body, `--muted-text` untuk teks sekunder

## Typography & Hierarchy
- Font: Poppins (300/400/600/700)
- Skala heading: h1 (3rem), h2 (2rem), h3 (1.5rem)
- Subjudul: `.subtitle` dengan `--fs-lg`
- Body: `--fs-md` (1rem), line-height 1.6

## Spacing
- Skala: `--space-1` s/d `--space-8`
- Gunakan `.section` untuk blok konten besar
- Hindari padding/ margin acak; refer ke skala spacing

## Komponen & States
### Buttons
- Variants: Primary, Secondary, Outline, Ghost
- Sizes: LG, MD (default), SM
- Disabled: gunakan atribut `disabled` dan biarkan CSS mengatur visual
- Interaksi: hover (warna/scale), ripple (JS), focus ring (aksesibilitas)

### Cards
- Shadow `--shadow-sm` default; hover naik dan `--shadow-lg`
- Gunakan `.card-image` untuk gambar dengan `object-fit: cover`

### Forms
- Fokus: border-color ke `--primary-purple` + focus-ring 3px
- Validasi: tampilkan error secara konsisten dengan `.error-message` jika diperlukan

### Nav & Header
- Sticky header, animasi underline pada item nav
- `header.scrolled` ditambahkan saat scroll untuk bayangan lebih tegas

## Responsif
- Breakpoint utama: `max-width: 768px`
- Menu mobile menggunakan toggle; search-form ikut toggle
- Grid otomatis dengan `repeat(auto-fit, minmax(300px, 1fr))`

## Micro-Interactions
- Smooth scrolling untuk anchor
- Reveal-on-scroll via IntersectionObserver
- Button ripple via JS
- Performa: gunakan event listener `passive` dan batasi pekerjaan di scroll

## Implementasi
- CSS di `css/styles.css` berisi variabel, komponen, dan utilitas
- Responsif di `css/styles.css` dan `css/responsive.css`
- JS di `js/scripts.js` untuk interaksi
- Style Guide di `styleguide.php` (contoh komponen dan warna)

## Pedoman Developer
- Gunakan class utilitas (`.subtitle`, `.text-muted`, `.section`, `.divider`, `.badge`, `.chip`) untuk konsistensi
- Hindari inline style kecuali demo; prefer class
- Ikuti skala spacing & typography saat menambah UI baru
- Pastikan states (hover, focus, active) diimplementasikan konsisten untuk aksesibilitas

