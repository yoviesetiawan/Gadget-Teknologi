# GadgetCute Style Guide

## Palet Warna
- Primary: `--primary-purple` (#6a4c93), `--soft-pink` (#ffacd5)
- Secondary: `--purple-300`, `--pink-300`
- Background: `--white`, `--neutral-100`
- Accent: `--dark-purple`, `--pink-700`
- Gradients: `--gradient-soft`, `--gradient-primary`

## Typography
- Font: Poppins (300/400/600/700)
- Skala: `--fs-xs`, `--fs-sm`, `--fs-md`, `--fs-lg`, `--fs-xl`, `--fs-2xl`, `--fs-3xl`, `--fs-4xl`
- Heading: `h1`, `h2`, `h3`
- Subjudul: `.subtitle`
- Teks netral: `.text-muted`

## Spacing
- Skala: `--space-1` (4px) s/d `--space-8` (64px)
- Section: `.section` untuk padding vertikal halaman
- Header section: `.section-header` untuk judul block

## Komponen
- Buttons: `.btn`, `.btn-secondary`, `.btn-outline`, `.btn-ghost`, `.btn-lg`, `.btn-sm`, `.btn-icon`
- Cards: `.card`, `.card-image`, `.card-content`
- Grid: `.grid` (auto-fit, minmax 300px)
- Forms: `.form-group` (label + input/textarea/select) dengan focus ring
- Badge: `.badge`, `.badge.pink`
- Chip: `.chip`

## Utilitas
- Divider: `.divider`
- Reveal on scroll: `.reveal` + `.in`
- Header scrolled: `header.scrolled` (ditambah saat scroll)

## Prinsip Desain
- Konsistensi spacing, warna, dan typografi di seluruh halaman
- Gunakan whitespace yang cukup untuk tampilan clean
- Hierarchy visual melalui heading, subjudul, dan ukuran elemen
- Interaksi halus (hover, fokus, ripple)

