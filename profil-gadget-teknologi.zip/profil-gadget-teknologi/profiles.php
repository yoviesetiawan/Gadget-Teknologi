<?php
// profiles.php
 $pageTitle = 'Daftar Gadget';
require_once 'includes/header.php';
require_once 'functions.php';

// Ambil parameter filter dan sort dari URL
 $currentCategory = isset($_GET['category']) ? $_GET['category'] : 'all';
 $sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'tanggal_ditambahkan';

// Panggil fungsi dengan parameter yang sudah diambil
 $allGadgets = getAllGadgets($currentCategory, $sortBy);
?>

<div class="container">
    <h2>Semua Profil Gadget</h2>

    <!-- BARU: Filter & Sort Bar -->
    <div class="filter-sort-bar">
        <form method="GET" action="profiles.php">
            <div class="form-group">
                <label for="category">Filter Kategori:</label>
                <select name="category" id="category" onchange="this.form.submit()">
                    <option value="all" <?php echo ($currentCategory == 'all') ? 'selected' : ''; ?>>Semua Kategori</option>
                    <option value="Smartphone" <?php echo ($currentCategory == 'Smartphone') ? 'selected' : ''; ?>>Smartphone</option>
                    <option value="Tablet" <?php echo ($currentCategory == 'Tablet') ? 'selected' : ''; ?>>Tablet</option>
                    <option value="Audio" <?php echo ($currentCategory == 'Audio') ? 'selected' : ''; ?>>Audio</option>
                </select>
            </div>
            <div class="form-group">
                <label for="sort">Urutkan:</label>
                <select name="sort" id="sort" onchange="this.form.submit()">
                    <option value="tanggal_ditambahkan" <?php echo ($sortBy == 'tanggal_ditambahkan') ? 'selected' : ''; ?>>Terbaru</option>
                    <option value="harga_asc" <?php echo ($sortBy == 'harga_asc') ? 'selected' : ''; ?>>Harga Terendah</option>
                    <option value="harga_desc" <?php echo ($sortBy == 'harga_desc') ? 'selected' : ''; ?>>Harga Tertinggi</option>
                    <option value="nama" <?php echo ($sortBy == 'nama') ? 'selected' : ''; ?>>Nama (A-Z)</option>
                </select>
            </div>
        </form>
    </div>

    <div class="grid">
        <?php if (count($allGadgets) > 0): ?>
            <?php foreach ($allGadgets as $gadget): ?>
                <div class="card">
                    <img src="images/gadgets/<?php echo htmlspecialchars($gadget['gambar']); ?>" alt="<?php echo htmlspecialchars($gadget['nama']); ?>" class="card-image">
                    <div class="card-content">
                        <h3><?php echo htmlspecialchars($gadget['nama']); ?></h3>
                        <p><?php echo substr(htmlspecialchars($gadget['deskripsi']), 0, 100) . '...'; ?></p>
                        <a href="profile-detail.php?id=<?php echo $gadget['id']; ?>" class="btn" style="margin-top: 15px;">Lihat Detail</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Tidak ada gadget yang ditemukan untuk kriteria ini.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>