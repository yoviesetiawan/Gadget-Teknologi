<?php
// news.php
 $pageTitle = 'Berita & Tips';
require_once 'includes/header.php';
require_once 'functions.php';

 $allNews = getAllNews();
?>

<div class="container">
    <h2>Berita & Tips Terkini</h2>
    <div class="grid">
        <?php if (count($allNews) > 0): ?>
            <?php foreach ($allNews as $article): ?>
                <div class="card">
                    <img src="images/news/<?php echo htmlspecialchars($article['gambar']); ?>" alt="<?php echo htmlspecialchars($article['judul']); ?>" class="card-image">
                    <div class="card-content">
                        <h3><?php echo htmlspecialchars($article['judul']); ?></h3>
                        <p><small>Oleh <?php echo htmlspecialchars($article['penulis']); ?> pada <?php echo date('d M Y', strtotime($article['tanggal_publikasi'])); ?></small></p>
                        <p><?php echo substr(htmlspecialchars($article['konten']), 0, 150) . '...'; ?></p>
                        <a href="news-detail.php?id=<?php echo $article['id']; ?>" class="btn" style="margin-top: 15px;">Baca Selengkapnya</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Belum ada berita.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>