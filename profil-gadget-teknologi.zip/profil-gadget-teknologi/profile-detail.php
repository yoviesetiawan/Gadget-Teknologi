<?php
// profile-detail.php
require_once 'includes/header.php';
require_once 'functions.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<div class='container'><h1>Error</h1><p>ID Gadget tidak valid.</p></div>";
    require_once 'includes/footer.php';
    exit;
}

 $gadget = getGadgetById($_GET['id']);

if (!$gadget) {
    echo "<div class='container'><h1>Error</h1><p>Gadget tidak ditemukan.</p></div>";
    require_once 'includes/footer.php';
    exit;
}

 $pageTitle = htmlspecialchars($gadget['nama']);

// AMBIL GADGET TERKAIT MENGGUNAKAN FUNGSI BARU
 $relatedGadgets = getRelatedGadgets($gadget['id']);
?>

<div class="container">
    <div class="detail-container">
        <div>
            <img src="images/gadgets/<?php echo htmlspecialchars($gadget['gambar']); ?>" alt="<?php echo htmlspecialchars($gadget['nama']); ?>" class="detail-image">
        </div>
        <div class="detail-info">
            <h1><?php echo htmlspecialchars($gadget['nama']); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($gadget['deskripsi'])); ?></p>
            <div class="price">Rp <?php echo number_format($gadget['harga'], 0, ',', '.'); ?></div>
            <h3>Spesifikasi</h3>
            <div class="specs"><?php echo nl2br(htmlspecialchars($gadget['spesifikasi'])); ?></div>
        </div>
    </div>

    <!-- SECTION BARU: Gadget Terkait -->
    <hr style="margin: 60px 0; border: 0; border-top: 2px solid var(--light-pink);">
    
    <section id="related-items">
        <h2>Gadget Lainnya yang Mungkin Kamu Suka</h2>
        <div class="grid">
            <?php if (count($relatedGadgets) > 0): ?>
                <?php foreach ($relatedGadgets as $related): ?>
                    <div class="card">
                        <img src="images/gadgets/<?php echo htmlspecialchars($related['gambar']); ?>" alt="<?php echo htmlspecialchars($related['nama']); ?>" class="card-image">
                        <div class="card-content">
                            <h3><?php echo htmlspecialchars($related['nama']); ?></h3>
                            <p><?php echo substr(htmlspecialchars($related['deskripsi']), 0, 100) . '...'; ?></p>
                            <a href="profile-detail.php?id=<?php echo $related['id']; ?>" class="btn" style="margin-top: 15px;">Lihat Detail</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada gadget lain untuk saat ini.</p>
            <?php endif; ?>
        </div>
    </section>

</div>

<?php require_once 'includes/footer.php'; ?>